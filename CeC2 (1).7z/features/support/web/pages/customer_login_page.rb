# frozen_string_literal: true

class CustomerLoginPage < BasePage
  attr_reader :customer_name_field, :customer_item_field
  def initialize
    @customer_name_field = EL['customer_name_field']
    @customer_item_field = EL['customer_item_field']
  end

  def customer_login(user)
    find_field(@customer_name_field).send_keys(user)
  end

  def send_element
    find(@customer_item_field).click
  end

  def login_user_business
    nome.set 'teste social'
    clienteBusiness.click
  end

  def clicar_iniciar_sessao
    btnIniciar.click
  end
end
