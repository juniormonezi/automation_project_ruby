# frozen_string_literal: true

# login
Dado('que o usuário esta na página de login') do
  @page.login_page.go
end

Dado('que o usuario efetuou o login') do
  @page.login_page.go
  steps %{
    Quando enviar as informações de login
  }
end
