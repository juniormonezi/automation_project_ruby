# frozen_string_literal: true

Quando('enviar as informações de usuário {string}') do |user|
  @page.customer_page.customer_login(user)
end

Quando('selecionar o usuário retornado') do
  @page.customer_page.send_element
end

Quando('enviar as informações do formulario de login') do
  pending # Write code here that turns the phrase above into concrete actions
end

Então('sistema deverá exibir a tela da PLP') do
end
